package proyecto;
import javax.swing.JOptionPane;
public class Main {
    public static void main(String[] args) {

       
     Menu p=new Menu();
    p.mostrarMenu();
    
       
        
    }
    
}
